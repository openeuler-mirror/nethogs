This folder contains user-contributed scripts.

The Nethogs project does not make claims about the quality of the scripts, maintains
them in any way, or necessarily think they're a good idea in the first place :).
